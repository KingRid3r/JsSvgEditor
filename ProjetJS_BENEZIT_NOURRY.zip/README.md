# JsSvgEditor

+ Pour le bon fonctionnement de notre application il faut utilisé webpack pour l'installer vous pouvez utilisé ce très bon tutoriel :  https://www.alsacreations.com/tuto/lire/1754-debuter-avec-webpack.html
+ Pour tout probleme de configuration WebPack vous pouvez vous réfférer a notre GitHub
+ Il vous suffira ensuite de decompresser l'archive dans le dossier de webpack
+ Lancer l'application avec npm run start
